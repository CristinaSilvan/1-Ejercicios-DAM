

var numero1=parseInt(prompt("Introduce el primer valor"))

var resultado=numero1*166.386

window.alert("La equivalencia en pesetas es: " + resultado)